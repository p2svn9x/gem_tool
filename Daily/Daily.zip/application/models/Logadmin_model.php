<?php
Class Logadmin_model extends MY_Model
{
    var $table = 'log_admin';
}