<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Đại lý Xengclub</title>

<meta name="robots" content="noindex, nofollow" />
<link rel="stylesheet" href="<?php echo public_url('admin') ?>/bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo public_url('admin')?>/font-awesome/css/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="<?php echo public_url('admin')?>/dist/css/ajax/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo public_url('admin') ?>/dist/css/AdminLTE.min.css">
<!-- AdminLTE Skins. Choose a skin from the css/skins
     folder instead of downloading all of them to reduce the load. -->
<link rel="stylesheet" href="<?php echo public_url('admin') ?>/dist/css/skins/_all-skins.min.css">
<!-- iCheck -->
<link rel="stylesheet" href="<?php echo public_url('admin') ?>/plugins/iCheck/flat/blue.css">
<!-- Date Picker -->
<link rel="stylesheet" href="<?php echo public_url('admin') ?>/plugins/datepicker/bootstrap-datetimepicker.css">
<!-- Daterange picker -->

<!-- bootstrap wysihtml5 - text editor -->
<link rel="stylesheet" href="<?php echo public_url('admin') ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
<script src="<?php echo public_url('admin') ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo public_url('admin')?>/plugins/jQueryUI/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo public_url('admin') ?>/bootstrap/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="<?php echo public_url('admin')?>/plugins/raphael-min.js"></script>

<!-- daterangepicker -->
<script src="<?php echo public_url('admin')?>/plugins/datepicker/moment.js"></script>

<script src="<?php echo public_url('admin') ?>/plugins/datepicker/bootstrap-datetimepicker.min.js"></script>

<script src="<?php echo public_url('admin') ?>/plugins/jQuery/jquery.twbsPagination.js"></script>
<script src="<?php echo public_url('admin') ?>/dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!--<script src="--><?php //echo public_url('admin') ?><!--/dist/js/pages/dashboard.js"></script>-->
<!-- AdminLTE for demo purposes -->

<script src="<?php echo public_url('admin') ?>/dist/js/demo.js"></script>
<script src="<?php echo public_url('admin') ?>/plugins/ckeditor/ckeditor.js"></script>
<script src="<?php echo public_url('admin') ?>/plugins/blockUI/jquery.blockUI.js"></script>
<script src="<?php echo public_url('admin') ?>/plugins/jQuery/jquery.table2excel.js"></script>

<script>
    $('a.verify_action').click(function(){
        if(!confirm('Bạn chắc chắn muốn xóa ?'))
        {
            return false;
        }
    });
</script>