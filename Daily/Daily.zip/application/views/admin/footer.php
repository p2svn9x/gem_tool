<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.1
    </div>
    <strong>Copyright &copy; 2016 <a href="http://vinplay.com">Vinplay</a>.</strong> All rights
    reserved.
</footer>